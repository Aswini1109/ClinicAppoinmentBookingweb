/* Clinic Booking — patient flow */
(function () {
  'use strict';

  const state = {
    step: 1,
    optionId: null,
    date: null,
    time: null,
    paid: false,
    otp: null,
    lastId: null,
  };

  const STEPS = ['Service', 'Date', 'Time', 'Details', 'Pay', 'Done'];

  function $(id) { return document.getElementById(id); }

  function getOption() {
    return BOOKING_OPTIONS.find(o => o.id === state.optionId) || null;
  }

  function canGoStep2() { return !!state.optionId; }
  function canGoStep3() { return !!state.date; }
  function canGoStep4() { return !!state.time; }
  function canGoStep5() {
    const name = $('patientName').value.trim();
    const age = $('patientAge').value;
    const phone = $('patientPhone').value.trim();
    const otp = $('otpInput').value.trim();
    return name.length >= 2 && age && /^[6-9]\d{9}$/.test(phone) && otp === state.otp && state.otp;
  }

  function updateButtons() {
    $('btnStep1').disabled = !canGoStep2();
    $('btnStep2').disabled = !canGoStep3();
    $('btnStep3').disabled = !canGoStep4();
    $('btnStep4').disabled = !canGoStep5();
  }

  function renderSteps() {
    $('stepBar').innerHTML = STEPS.map((label, i) => {
      const n = i + 1;
      let c = 'step-pill';
      if (n === state.step) c += ' active';
      else if (n < state.step) c += ' done';
      return `<span class="${c}">${n}. ${label}</span>`;
    }).join('');

    for (let i = 1; i <= 6; i++) {
      $('panel' + i).classList.toggle('hidden', i !== state.step);
    }
  }

  function goStep(n) {
    if (n === 2 && !canGoStep2()) return;
    if (n === 3 && !canGoStep3()) return;
    if (n === 4 && !canGoStep4()) return;
    if (n === 5 && !canGoStep5()) return;
    state.step = n;
    renderSteps();
    if (n === 1) renderServiceGrid();
    if (n === 2) renderDateGrid();
    if (n === 3) renderTimeGrid();
    if (n === 5) $('upiId').textContent = CLINIC.upiId;
    updateButtons();
  }

  /* Grid 1 — max 10 service options */
  function renderServiceGrid() {
    const items = BOOKING_OPTIONS.slice(0, MAX_GRID);
    $('gridService').innerHTML = items.map(o => `
      <button type="button" class="grid-item ${state.optionId === o.id ? 'selected' : ''}" data-option="${o.id}">
        <span class="grid-emoji">${o.emoji}</span>
        <strong>${o.doctor}</strong>
        <span class="grid-sub">${o.service}</span>
        <span class="grid-price">₹${o.fee}</span>
      </button>
    `).join('');
  }

  /* Grid 2 — next 10 days */
  function renderDateGrid() {
    const days = getNextDays(MAX_GRID);
    $('gridDate').innerHTML = days.map(d => {
      const dt = new Date(d + 'T12:00:00');
      const label = dt.toLocaleDateString('en-IN', { weekday: 'short' });
      const num = dt.getDate();
      const mon = dt.toLocaleDateString('en-IN', { month: 'short' });
      const isToday = d === formatDateLocal(new Date());
      return `
        <button type="button" class="grid-item grid-date ${state.date === d ? 'selected' : ''}" data-date="${d}">
          <span class="grid-sub">${label}${isToday ? ' · Today' : ''}</span>
          <strong class="grid-day-num">${num}</strong>
          <span class="grid-sub">${mon}</span>
        </button>
      `;
    }).join('');
  }

  /* Grid 3 — max 10 time slots */
  function renderTimeGrid() {
    const opt = getOption();
    if (!opt || !state.date) return;

    const booked = getBookedSlots(state.date, opt.doctorId);
    const slots = TIME_SLOTS.slice(0, MAX_GRID);

    $('timeDateLabel').textContent = formatDisplayDate(state.date);
    $('gridTime').innerHTML = slots.map(t => {
      const taken = booked.includes(t);
      const sel = state.time === t;
      return `
        <button type="button"
          class="grid-item grid-time ${taken ? 'disabled' : ''} ${sel ? 'selected' : ''}"
          data-time="${t}"
          ${taken ? 'disabled' : ''}>
          ${formatTime12(t)}
          ${taken ? '<small>Booked</small>' : '<small>Free</small>'}
        </button>
      `;
    }).join('');

    $('timeLegend').innerHTML = `
      <span class="tag tag-green">● Free</span>
      <span class="tag tag-grey">● Booked</span>
    `;
  }

  function sendOTP() {
    const phone = $('patientPhone').value.trim();
    if (!/^[6-9]\d{9}$/.test(phone)) {
      alert('Valid 10-digit mobile number enter properly');
      return;
    }
    state.otp = String(Math.floor(100000 + Math.random() * 900000));
    $('otpInput').disabled = false;
    $('otpHint').classList.remove('hidden');
    $('otpHint').innerHTML = `Demo OTP: <b>${state.otp}</b>`;
    $('sendOtpBtn').textContent = 'Resend OTP';
    showToast(`OTP: ${state.otp} — booking verify using OTP`);
    updateButtons();
  }

  function confirmBooking() {
    const opt = getOption();
    const apt = {
      id: 'apt-' + Date.now(),
      optionId: opt.id,
      doctorId: opt.doctorId,
      doctorName: opt.doctor,
      service: opt.service,
      fee: opt.fee,
      date: state.date,
      time: state.time,
      name: $('patientName').value.trim(),
      age: parseInt($('patientAge').value, 10),
      phone: $('patientPhone').value.trim(),
      problem: $('patientProblem').value.trim(),
      paid: state.paid,
      status: 'confirmed',
    };

    addAppointment(apt);
    state.lastId = apt.id;

    $('confirmBox').innerHTML = `
      <p><span>Doctor</span><b>${opt.doctor} — ${opt.service}</b></p>
      <p><span>Date</span><b>${formatDisplayDate(apt.date)}, ${formatTime12(apt.time)}</b></p>
      <p><span>Patient</span><b>${apt.name}, ${apt.age} yrs</b></p>
      <p><span>Fee</span><b>₹${apt.fee}</b></p>
      <p><span>Token</span><b>${apt.paid ? '₹100 Paid ✓' : 'Skipped'}</b></p>
      <p><span>ID</span><b>${apt.id}</b></p>
    `;

    $('mapLink').href = CLINIC.mapLink;
    showToast(`Confirmed! ${opt.doctor} — ${formatDisplayDate(apt.date)} ${formatTime12(apt.time)}`);
    goStep(6);
  }

  function resetAll() {
    state.optionId = null;
    state.date = null;
    state.time = null;
    state.paid = false;
    state.otp = null;
    state.lastId = null;
    $('patientName').value = '';
    $('patientAge').value = '';
    $('patientPhone').value = '';
    $('patientProblem').value = '';
    $('otpInput').value = '';
    $('otpInput').disabled = true;
    $('otpHint').classList.add('hidden');
    $('btnStep5').disabled = true;
    goStep(1);
    $('booking').scrollIntoView({ behavior: 'smooth' });
  }

  /* Event delegation — no broken inline onclick */
  document.addEventListener('click', function (e) {
    const t = e.target.closest('[data-option]');
    if (t) {
      state.optionId = parseInt(t.dataset.option, 10);
      renderServiceGrid();
      updateButtons();
      return;
    }

    const d = e.target.closest('[data-date]');
    if (d) {
      state.date = d.dataset.date;
      state.time = null;
      renderDateGrid();
      updateButtons();
      return;
    }

    const tm = e.target.closest('[data-time]:not(.disabled)');
    if (tm && !tm.disabled) {
      state.time = tm.dataset.time;
      renderTimeGrid();
      updateButtons();
    }
  });

  $('btnStep1').addEventListener('click', () => goStep(2));
  $('btnStep2').addEventListener('click', () => goStep(3));
  $('btnStep3').addEventListener('click', () => goStep(4));
  $('btnStep4').addEventListener('click', () => goStep(5));
  $('btnBack2').addEventListener('click', () => goStep(1));
  $('btnBack3').addEventListener('click', () => goStep(2));
  $('btnBack4').addEventListener('click', () => goStep(3));
  $('btnBack5').addEventListener('click', () => goStep(4));
  $('sendOtpBtn').addEventListener('click', sendOTP);
  $('btnPay').addEventListener('click', () => { state.paid = true; $('btnStep5').disabled = false; showToast('₹100 UPI payment received!'); });
  $('btnSkipPay').addEventListener('click', () => { state.paid = false; $('btnStep5').disabled = false; });
  $('btnStep5').addEventListener('click', confirmBooking);
  $('btnReset').addEventListener('click', resetAll);
  $('bookNow').addEventListener('click', () => $('booking').scrollIntoView({ behavior: 'smooth' }));

  ['patientName', 'patientAge', 'patientPhone', 'otpInput'].forEach(id => {
    $(id).addEventListener('input', updateButtons);
  });

  renderServiceGrid();
  renderSteps();
  updateButtons();
})();
