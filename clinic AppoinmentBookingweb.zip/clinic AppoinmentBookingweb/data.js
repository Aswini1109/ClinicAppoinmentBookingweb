/* Clinic Booking — shared data & storage */
const CLINIC = {
  name: 'Chennai Skin & Wellness Clinic',
  location: 'Anna Nagar, Chennai - 600040',
  mapLink: 'https://maps.google.com/?q=Anna+Nagar+Chennai',
  upiId: 'chennaiclinic@upi',
  tokenFee: 100,
};

const MAX_GRID = 10;

/* Single grid: doctor + service combined (max 10 options) */
const BOOKING_OPTIONS = [
  { id: 1, doctorId: 'dr-meena-sharma', doctor: 'Dr. Meena Sharma', specialty: 'Dermatology', service: 'Skin Consultation', fee: 500, emoji: '👩‍⚕️' },
  { id: 2, doctorId: 'dr-karthik-raj', doctor: 'Dr. Karthik Raj', specialty: 'General Medicine', service: 'General Health Checkup', fee: 350, emoji: '🩺' },
  { id: 3, doctorId: 'dr-arun-kumar', doctor: 'Dr. Arun Kumar', specialty: 'Dentistry', service: 'Dental Cleaning', fee: 700, emoji: '🦷' },
  { id: 4, doctorId: 'dr-priya-menon', doctor: 'Dr. Priya Menon', specialty: 'Pediatrics', service: 'Child Health Checkup', fee: 400, emoji: '👶' },
  { id: 5, doctorId: 'dr-suresh-babu', doctor: 'Dr. Suresh Babu', specialty: 'Orthopedics', service: 'Bone & Joint Pain', fee: 600, emoji: '🦴' },
  { id: 6, doctorId: 'dr-anitha-rao', doctor: 'Dr. Anitha Rao', specialty: 'Gynecology', service: 'Women Health Checkup', fee: 550, emoji: '🤰' },
  { id: 7, doctorId: 'dr-vijay-krishna', doctor: 'Dr. Vijay Krishna', specialty: 'Cardiology', service: 'ECG & Heart Checkup', fee: 800, emoji: '❤️' },
  { id: 8, doctorId: 'dr-lakshmi-nair', doctor: 'Dr. Lakshmi Nair', specialty: 'Ophthalmology', service: 'Eye Test & Checkup', fee: 300, emoji: '👁️' },
  { id: 9, doctorId: 'dr-rahul-verma', doctor: 'Dr. Rahul Verma', specialty: 'ENT', service: 'Ear Nose Throat', fee: 450, emoji: '👂' },
  { id: 10, doctorId: 'dr-kavitha-reddy', doctor: 'Dr. Kavitha Reddy', specialty: 'Physiotherapy', service: 'Pain Relief Therapy', fee: 500, emoji: '💪' }
];

const TIME_SLOTS = [
  '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '15:00', '15:30', '16:00', '16:30',
];

const DEFAULT_SCHEDULE = {
  workDays: [1, 2, 3, 4, 5, 6],
  sundayOff: true,
};

function formatDateLocal(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function formatDisplayDate(dateStr) {
  const d = new Date(dateStr + 'T12:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
}

function formatTime12(time24) {
  const [h, m] = time24.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${String(m).padStart(2, '0')} ${ampm}`;
}

function getNextDays(count) {
  const days = [];
  const today = new Date();
  today.setHours(12, 0, 0, 0);
  let added = 0;
  let offset = 0;
  while (added < count && offset < 30) {
    const d = new Date(today);
    d.setDate(today.getDate() + offset);
    offset++;
    const dayNum = d.getDay();
    if (DEFAULT_SCHEDULE.sundayOff && dayNum === 0) continue;
    if (!DEFAULT_SCHEDULE.workDays.includes(dayNum)) continue;
    days.push(formatDateLocal(d));
    added++;
  }
  return days;
}

function getStore() {
  try {
    const raw = localStorage.getItem('clinicBooking_v2');
    if (raw) return JSON.parse(raw);
  } catch (e) { /* ignore corrupt data */ }

  const today = formatDateLocal(new Date());
  const initial = {
    appointments: [{
      id: 'apt-demo-1',
      optionId: 1,
      doctorId: 'dr-meena',
      doctorName: 'Dr. Meena',
      service: 'Skin Consultation',
      fee: 500,
      date: today,
      time: '11:00',
      name: 'Ravi Kumar',
      age: 34,
      phone: '9876543210',
      problem: 'Skin rash',
      paid: true,
      status: 'confirmed',
    }],
    patients: [
      { phone: '9876543210', name: 'Ravi Kumar', age: 34, lastVisit: today, notes: 'BP: 130/85' },
      { phone: '9123456789', name: 'Priya S', age: 28, lastVisit: '2026-01-20', notes: 'Skin allergy' },
    ],
  };
  saveStore(initial);
  return initial;
}

function saveStore(data) {
  localStorage.setItem('clinicBooking_v2', JSON.stringify(data));
}

function getBookedSlots(dateStr, doctorId) {
  return getStore().appointments
    .filter(a => a.date === dateStr && a.doctorId === doctorId && a.status !== 'cancelled')
    .map(a => a.time);
}

function addAppointment(apt) {
  const store = getStore();
  store.appointments.push(apt);
  let p = store.patients.find(x => x.phone === apt.phone);
  if (p) {
    p.name = apt.name;
    p.age = apt.age;
    p.lastVisit = apt.date;
    if (apt.problem) p.notes = apt.problem;
  } else {
    store.patients.push({ phone: apt.phone, name: apt.name, age: apt.age, lastVisit: apt.date, notes: apt.problem || '' });
  }
  saveStore(store);
}

function showToast(msg) {
  document.querySelectorAll('.toast').forEach(t => t.remove());
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `<strong>💬 WhatsApp</strong><p>${msg}</p>`;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 6000);
}
